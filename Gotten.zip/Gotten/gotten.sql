-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 18, 2020 at 01:27 PM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.3.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gotten`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `email` varchar(225) NOT NULL,
  `password` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `email`, `password`) VALUES
(1, 'oladelep77@gmail.com', 'cd3df3b2d328c564e3d6480cb00167b9');

-- --------------------------------------------------------

--
-- Table structure for table `company`
--

CREATE TABLE `company` (
  `id` int(11) NOT NULL,
  `name` varchar(225) NOT NULL,
  `email` varchar(225) NOT NULL,
  `password` varchar(225) NOT NULL,
  `about` varchar(225) NOT NULL,
  `country` varchar(225) NOT NULL,
  `state` varchar(225) NOT NULL,
  `address` varchar(225) NOT NULL,
  `image` varchar(225) NOT NULL,
  `created_at` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `company`
--

INSERT INTO `company` (`id`, `name`, `email`, `password`, `about`, `country`, `state`, `address`, `image`, `created_at`) VALUES
(1, 'Tech Spot NG', 'oladeleprecious011@gmail.com', 'cd3df3b2d328c564e3d6480cb00167b9', 'We build techs for developers', 'Nigeria', 'Ogun state', '10, ojerinde street, Akute', 'bot.jpg', '2020-06-13');

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE `jobs` (
  `id` int(11) NOT NULL,
  `name` varchar(225) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(225) NOT NULL,
  `first` varchar(225) NOT NULL,
  `sec` varchar(225) NOT NULL,
  `third` varchar(225) NOT NULL,
  `fourth` varchar(225) NOT NULL,
  `last` varchar(225) NOT NULL,
  `qualification` varchar(225) NOT NULL,
  `benefit` varchar(225) NOT NULL,
  `salary` varchar(255) NOT NULL,
  `vacancy` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `experience` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `deadline` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `posted_at` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jobs`
--

INSERT INTO `jobs` (`id`, `name`, `title`, `description`, `first`, `sec`, `third`, `fourth`, `last`, `qualification`, `benefit`, `salary`, `vacancy`, `status`, `experience`, `location`, `gender`, `deadline`, `image`, `posted_at`) VALUES
(1, 'Tech Spot NG', 'Web Developer', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Debitis illum fuga eveniet. Deleniti asperiores, commodi quae ipsum quas est itaque, ipsa, dolore beatae voluptates nemo blanditiis iste eius officia minus.\r\n\r\nVelit u', 'Necessitatibus quibusdam facilis', ' Velit unde aliquam et voluptas reiciendis n Velit unde aliquam et voluptas reiciendis non sapiente labore', ' Commodi quae ipsum quas est itaque', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit', ' Deleniti asperiores blanditiis nihil quia officiis dolor', 'Necessitatibus quibusdam facilis\r\nVelit unde aliquam et voluptas reiciendis non sapiente labore\r\nCommodi quae ipsum quas est itaque\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit\r\nDeleniti asperiores blanditiis nih', 'Necessitatibus quibusdam facilis\r\nVelit unde aliquam et voluptas reiciendis non sapiente labore\r\nCommodi quae ipsum quas est itaque\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit\r\nDeleniti asperiores blanditiis nih', '$60k - $100k', '20', 'Full Time', '2 or 3year(s)', 'New York City', 'Male', 'April 28, 2020', 'all.jpeg', '2020-06-13'),
(2, 'Tech Spot NG', 'Software Dev', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Debitis illum fuga eveniet. Deleniti asperiores, commodi quae ipsum quas est itaque, ipsa, dolore beatae voluptates nemo blanditiis iste eius officia minus.\r\n\r\nVelit u', 'Necessitatibus quibusdam facilis', 'Velit unde aliquam et voluptas reiciendis n Velit unde aliquam et voluptas reiciendis non sapiente labore', 'Commodi quae ipsum quas est itaque', ' Lorem ipsum dolor sit amet, consectetur adipisicing elit', 'Deleniti asperiores blanditiis nihil quia officiis dolor', '\r\nNecessitatibus quibusdam facilis\r\nVelit unde aliquam et voluptas reiciendis non sapiente labore\r\nCommodi quae ipsum quas est itaque\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit\r\nDeleniti asperiores blanditiis n', '\r\nNecessitatibus quibusdam facilis\r\nVelit unde aliquam et voluptas reiciendis non sapiente labore\r\nCommodi quae ipsum quas est itaque\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit\r\nDeleniti asperiores blanditiis n', '$60k - $100k', '10', 'Part Time', '2 to 3 year(s)', 'Lagos', 'Any', 'May 28, 2020', 'amazon.png', '2020-06-13');

-- --------------------------------------------------------

--
-- Table structure for table `pending`
--

CREATE TABLE `pending` (
  `id` int(11) NOT NULL,
  `name` varchar(225) NOT NULL,
  `email` varchar(225) NOT NULL,
  `password` varchar(225) NOT NULL,
  `about` varchar(225) NOT NULL,
  `country` varchar(225) NOT NULL,
  `state` varchar(225) NOT NULL,
  `address` varchar(225) NOT NULL,
  `image` varchar(225) NOT NULL,
  `created_at` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pending`
--

INSERT INTO `pending` (`id`, `name`, `email`, `password`, `about`, `country`, `state`, `address`, `image`, `created_at`) VALUES
(3, 'Tech Spot NG', 'oladeleprecious013@gmail.com', 'cd3df3b2d328c564e3d6480cb00167b9', 'We build techs for dev', 'Niheria', 'Ogun', '10, ojerinde street', 'cmd.png', '2020-06-13');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `fname` varchar(225) NOT NULL,
  `email` varchar(225) NOT NULL,
  `password` varchar(225) NOT NULL,
  `pdf` varchar(255) NOT NULL,
  `image` varchar(225) NOT NULL,
  `created_at` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `fname`, `email`, `password`, `pdf`, `image`, `created_at`) VALUES
(2, 'precious oladele', 'oladelep77@gmail.com', 'cd3df3b2d328c564e3d6480cb00167b9', '_Django_Core1.pdf', 'devp1.jpg', '2020-06-13'),
(4, 'Precious Oladele', 'oladeleprecious013@gmail.com', 'cd3df3b2d328c564e3d6480cb00167b9', '', '', '2020-06-13');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `company`
--
ALTER TABLE `company`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pending`
--
ALTER TABLE `pending`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `company`
--
ALTER TABLE `company`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `pending`
--
ALTER TABLE `pending`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
